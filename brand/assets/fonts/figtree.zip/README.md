# Figtree

The Conduction body and heading face. Open Font License (OFL.txt).

## Contents

- `woff2/` — web fonts, weights 400 / 500 / 600 / 700, latin + latin-ext subsets
- `ttf/` — desktop installers, weights 400 / 500 / 600 / 700 (Figma, Keynote, Office)

## Quick @font-face

```css
@font-face {
  font-family: 'Figtree';
  font-style: normal;
  font-weight: 400 700;
  src: url('./woff2/Figtree-400-latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
                 U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F,
                 U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
```

Source: <https://github.com/erikdkennedy/figtree>
